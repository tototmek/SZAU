
%liczba neuron�w ukrytych: 1, liczba wej�� sieci: 4
%wej�cie 1: u(k-4)
%wej�cie 2: u(k-5)
%wej�cie 3: y(k-1)
%wej�cie 4: y(k-2)
%uczenie w trybie OE
w10(1,1)=-5.0768988580e-001; w1(1,1)=6.9709283371e-002; w1(1,2)=-2.6391291860e-001; w1(1,3)=-3.2045783623e-002; w1(1,4)=-2.6945746658e-001; 
w20=-1.4932843306e+000; w2(1)=-3.1708148367e+000; 

